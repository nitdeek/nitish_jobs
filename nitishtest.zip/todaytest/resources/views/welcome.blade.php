<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta charset="utf-8">
	<title>test2</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<style type="text/css">
		*{
	box-sizing: border-box;
}
body{
	background-color:#B2B3B3;
}
#first{
	border:1px solid #F2F3F3;
	width: 90%;
	margin: auto;
	background-color:#F2F3F3;
	margin-top: 2%;
}
#one{
	color: white;
	padding-top:4px;
	padding-bottom: 4px; 
	text-align: center;
	background-image:linear-gradient(to right, red, orange, yellow, green, blue, indigo, violet);
}

#insert{
	color: black;
	background-color: #0EEFFB;
	border:3px solid #2289EC;
	padding: 5px;
	cursor: pointer;
	margin-left: 2%;
    text-decoration:none;
}
#three{
	text-align: center;
	color: #555 !important;
	padding-bottom: 10px;
	margin-top: 0;
}
#three::after{
	content: '';
	background: #007bff;
	display: block;
	height: 3px;
	width: 170px;
	margin:10px auto 5px;
}
#four{
	border:1px solid #A7A8A8;
	width: 30%;
	text-align: center;
	cursor: pointer;
	display: inline-block;
	margin-left: 2%;
	margin-top: 1%;
	margin-bottom: 1%;
}
#four:hover{
	background: #007bff;
	color: white;
	transition: 0.5s;
}
#five{
	color: #555;
}
#five:hover{
	color: white;
	transition: 0.5s;

}
#five::after{
	content: '';
	background: #007bff;
	display: block;
	height: 3px;
	width: 170px;
	margin:8px auto 5px;
}


#second{
	border:1px solid #F2F3F3;
	width: 90%;
	margin: auto;
	background-color:#F2F3F3;
	margin-top: 2%;
	display: none;
}
#two{
margin:auto;
border-collapse: collapse;
margin-bottom: 2%;
width: 50%;
}
#two tr,#two td{
padding: 20px;
font-size: 20px;
color:#555;
}
input{
	padding: 10px;
	width: 100%;
}
#subs{
	border:3px solid #007bff;
}
#subs:hover{
background: #007bff;
	color: white;
	border:3px solid #007bff;
	transition: 0.5s;	
}
#submit:hover{
background: #007bff;
	color: white;
	border:3px solid #007bff;
	transition: 0.5s;	
}
#inner{
	width:100%;
}
#third{
	border:1px solid #F2F3F3;
	width: 90%;
	margin: auto;
	background-color:#F2F3F3;
	margin-top: 2%;
	display: none;
}
#info{
	border:1px solid #F2F3F3;
	margin:auto;
	width: 90%;

}
#jobs{
color: #555;
text-align: center;
}
#jobs::after{
	content: '';
	background: #007bff;
	display: block;
	height: 3px;
	width: 170px;
	margin:8px auto 5px;
}
#subss:hover{
background: #007bff;
	color: white;
	border:none;
	transition: 0.5s;	
}
#fourth{
	border:1px solid #F2F3F3;
	width: 90%;
	margin: auto;
	background-color:#F2F3F3;
	margin-top: 2%;
	display: none;
}
#cross{
color:white;

}
#right{
	float: right;
	margin-right: 4%;
	font-size: 30px;
}
#right:hover{
	color:#50BFE6;
}
#left{
	margin-left:4%;
	font-size: 30px; 
}
#left:hover{
color:#50BFE6;	
}

</style>
</head>
<body>
	<div id="first">
		<h1 id="one">Jobs Available</h1>
		<a href="/todaytest/public/insert" id="insert">INSERT JOB</a>
		<h1 id="three">Engineering</h1>
		<div id="inner">
        @foreach($jobs as $job)
        <div id="four" >
	    <a style="text-decoration:none;" href="delete/{{$job->id}}"><i id="cross"  style="float:right; margin-right:3%;margin-top:2%;" class="fa fa-times" aria-hidden="true"></i></a>
      
        <a href="info/{{$job->id}}" style="text-decoration:none;"  ><h2 id="five" >{{$job->job_name}}</h2></a>
        
		</div>
        @endforeach
		</div>
</div>
</body>