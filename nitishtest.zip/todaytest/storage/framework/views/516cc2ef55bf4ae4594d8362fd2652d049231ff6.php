<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta charset="utf-8">
	<title>test2</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<style type="text/css">
		*{
	box-sizing: border-box;
}
body{
	background-color:#B2B3B3;
}
#first{
	border:1px solid #F2F3F3;
	width: 90%;
	margin: auto;
	background-color:#F2F3F3;
	margin-top: 2%;
}
#one{
	color: white;
	padding-top:4px;
	padding-bottom: 4px; 
	text-align: center;
	background-image:linear-gradient(to right, red, orange, yellow, green, blue, indigo, violet);
}

#insert{
	color: black;
	background-color: #0EEFFB;
	border:3px solid #2289EC;
	padding: 5px;
	cursor: pointer;
	margin-left: 2%;
}
#three{
	text-align: center;
	color: #555 !important;
	padding-bottom: 10px;
	margin-top: 0;
}
#three::after{
	content: '';
	background: #007bff;
	display: block;
	height: 3px;
	width: 170px;
	margin:10px auto 5px;
}
#four{
	border:1px solid #A7A8A8;
	width: 30%;
	text-align: center;
	cursor: pointer;
	display: inline-block;
	margin-left: 2%;
	margin-top: 1%;
	margin-bottom: 1%;
}
#four:hover{
	background: #007bff;
	color: white;
	transition: 0.5s;
}
#five{
	color: #555;
}
#five:hover{
	color: white;
	transition: 0.5s;

}
#five::after{
	content: '';
	background: #007bff;
	display: block;
	height: 3px;
	width: 170px;
	margin:8px auto 5px;
}

#second{
	border:1px solid #F2F3F3;
	width: 90%;
	margin: auto;
	background-color:#F2F3F3;
	margin-top: 2%;
	display: none;
}
#two{
margin:auto;
border-collapse: collapse;
margin-bottom: 2%;
width: 50%;
}
#two tr,#two td{
padding: 20px;
font-size: 20px;
color:#555;
}
input{
	padding: 10px;
	width: 100%;
}
#subs{
	border:3px solid #007bff;
}
#subs:hover{
background: #007bff;
	color: white;
	border:3px solid #007bff;
	transition: 0.5s;	
}
#submit:hover{
background: #007bff;
	color: white;
	border:3px solid #007bff;
	transition: 0.5s;	
}
#inner{
	width:100%;
}
#third{
	border:1px solid #F2F3F3;
	width: 90%;
	margin: auto;
	background-color:#F2F3F3;
	margin-top: 2%;
    height:670px;
}
#info{
	border:1px solid #F2F3F3;
	margin:auto;
	width: 90%;

}
#jobs{
color: #555;
text-align: center;
}
#jobs::after{
	content: '';
	background: #007bff;
	display: block;
	height: 3px;
	width: 170px;
	margin:8px auto 5px;
}
#subss{
    padding:5px;
    margin-left:45%;
    text-decoration:none;
}
#subss:hover{
background: #007bff;
	color: white;
	border:none;
	transition: 0.5s;	
}
#fourth{
	border:1px solid #F2F3F3;
	width: 90%;
	margin: auto;
	background-color:#F2F3F3;
	margin-top: 2%;
	display: none;
}
#cross{
color:white;

}
#right{
	float: right;
	margin-right: 4%;
	font-size: 30px;
}
#right:hover{
	color:#50BFE6;
}
#left{
	margin-left:4%;
	font-size: 30px; 
}
#left:hover{
color:#50BFE6;	
}

</style>
</head>
<body>
	
<div id="third">
	<h1 id="one">Job Profile</h1>
	<a href="/todaytest/public/"><i id="left" class="fa fa-arrow-left" aria-hidden="true"></i></a>
	<div id="info">
    <h1 id="jobs"><?php echo e($job->job_name); ?></h1>
	<h2 style="color: #555;">Knowledge Required</h2>
	<p><?php echo e($job->description); ?></p>	
	<h2 style="color: #555;">Experience</h2>
	<p><?php echo e($job->experience); ?></p>
	<h2 style="color: #555;">Openings</h2>
	<p><?php echo e($job->openings); ?></p>
	<h2 style="color: #555;">CTC</h2>
	<p><?php echo e($job->ctc); ?></p>
	<h2 style="color: #555">Hiring Process</h2>
	<p><?php echo e($job->process); ?></p>
<a href="/todaytest/public/apply/<?php echo e($job->id); ?>" id="subss" style="font-size:20px;border:3px solid  #007bff;">Apply Now
</a>
	</div>
</div>
</body>
</html>