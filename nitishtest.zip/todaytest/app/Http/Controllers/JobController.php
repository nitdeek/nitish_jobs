<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\PresentJobs;
use App\Applier;

class JobController extends Controller
{
    function views(){
        $jobs=PresentJobs::all();
        return view('welcome',["jobs"=>$jobs]);    
    }
    function insert(){
        return view('inserting');
    }
    function inserted(Request $req){
        $job=new PresentJobs;
        $job->job_name=$req->input('job_name');
        $job->description=$req->input('description');
        $job->experience=$req->input('experience');
        $job->openings=$req->input('openings');
        $job->ctc=$req->input('ctc');
        $job->process=$req->input('process');
        $job->save();
        $jobs=PresentJobs::all();
        return view('welcome',["jobs"=>$jobs]);    

    }
    function info($ids){
        $job=PresentJobs::find($ids);
        return view('information',["job"=>$job]);
    }
    function apply($ids){
        $job=PresentJobs::find($ids);
        return view('applying',["job"=>$job]);
    }
    function submit(Request $req){
        $job=new Applier;
        $job->name=$req->input('name');
        $job->email=$req->input('email');
        $job->contact_no=$req->input('contact_no');
        $job->ctc=$req->input('ctc');
        $job->experience=$req->input('experience');
        $job->job=$req->input('job');
        $job->save();
       $jobs=PresentJobs::all();
        return view('welcome',["jobs"=>$jobs]);  
    }
    function delete($ids){
        $job=PresentJobs::find($ids);
        $job->delete();
        $jobs=PresentJobs::all();
        return view('welcome',["jobs"=>$jobs]);  

    }

}
